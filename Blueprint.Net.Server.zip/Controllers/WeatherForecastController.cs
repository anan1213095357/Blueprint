using Microsoft.AspNetCore.Mvc;
using static FreeSql.Internal.GlobalFilter;

namespace Blueprint.Net.Server.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class BlueprintController(ILogger<BlueprintController> logger, IFreeSql fsql) : ControllerBase
    {
        private readonly ILogger<BlueprintController> _logger = logger;
        private readonly IFreeSql _fsql = fsql;

        [HttpGet("GetProjects")]
        public ActionResult<IEnumerable<Project>> GetProjects()
        {
            var projects = _fsql.Select<Project>()
                .IncludeMany(p => p.Workspaces) // Include Workspaces
                .ToList();
            return Ok(projects);
        }

        [HttpPost("AddProject")]
        public ActionResult<Project> AddProject([FromBody] Project project)
        {

            var projectRepo = _fsql.GetRepository<Project>();

            projectRepo.DbContextOptions.EnableCascadeSave = true;


            project = projectRepo.Insert(project);



            return Ok(project);

        }


        [HttpPut("UpdateProject/{id}")]
        public IActionResult UpdateProject(int id, [FromBody] Project project)
        {
            var existingProject = _fsql.Select<Project>().Where(p => p.Id == id).ToOne();
            if (existingProject == null)
                return NotFound();

            existingProject.Name = project.Name;
            existingProject.Workspaces = project.Workspaces;
            _fsql.Update<Project>().SetSource(existingProject).ExecuteAffrows();
            return Ok();
        }

        [HttpDelete("DeleteProject/{id}")]
        public IActionResult DeleteProject(int id)
        {
            var ret = _fsql.Delete<Project>().Where(p => p.Id == id).ExecuteAffrows();
            if (ret > 0)
                return Ok();
            return NotFound();
        }
    }
}
